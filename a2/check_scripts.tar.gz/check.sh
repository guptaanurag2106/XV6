#!/bin/bash
submission=$1
mkdir -p ./test_dir > /dev/null 2>&1

echo "Processing submission: $submission"

# Extract the Entry number
entryNoRegex="assignment2_easy_([0-9]{4}[A-Z]{2}.{1}[0-9]{4}){1}_?([0-9]{4}[A-Z]{2}.{1}[0-9]{4})?.*.gz"
if [[ $submission =~ $entryNoRegex ]]; then
	entryNum1=${BASH_REMATCH[1]}
	entryNum2=${BASH_REMATCH[2]}
	# If group 1 exists (which it should if there's a match)
	if [ ! -z "$entryNum1" ]; then
		echo "Entry Number #1: $entryNum1"
		# If group 2 also exists, print it as well
        if [ ! -z "$entryNum2" ]; then
			echo "Entry Number #2: $entryNum2"
		fi
	fi
else
	echo "No match found."
fi

echo "Setting up the test directory..."
tar -xzvf "$submission" -C ./test_dir > /dev/null 2>&1
cp check_schedulability.py assig2_*.c *.sh ./test_dir > /dev/null 2>&1
cd ./test_dir

FILE=*[Rr][Ee][Pp][Oo][Rr][Tt]*.pdf
if ! ls $FILE 1> /dev/null 2>&1; then
    echo "Report does not exist"
fi

adduprogs() {
    # Modify Makefile and recompile for each test case, suppressing output except for errors
    echo "Modifying Makefile for $1" > /dev/null
    EXTRAUPROGS="UPROGS= $1"
    sed -i 's/_assig2_.//g' Makefile
    sed -i "s/UPROGS=/$EXTRAUPROGS/" Makefile
    make fs.img > /dev/null 2>&1
    make > /dev/null 2>&1
}

# Modify the Makefile to use the correct version of gcc, suppressing output
sed -i 's/gcc-100\|gcc-9/gcc/g' Makefile > /dev/null 2>&1

echo "Executing the test cases..."

# Ensure QEMU instances are not running before starting tests
pkill qemu-system-x86 > /dev/null 2>&1
pkill qemu-system-i386 > /dev/null 2>&1

make clean > /dev/null 2>&1

# Testing
check_test=5
total_test=0
# Compile Results
echo "" > .output
marks_1="$entryNum1 : "
marks_2="$entryNum1 : "
# Running each test case
for ((t=1; t<=$check_test; ++t))
do
    adduprogs "_assig2_$t"
    timeout 30s ./test_assig2.sh assig2_$t | grep -i 'the completed process' | sed 's/$ //g' > "res_assig2_$t"

	echo -n "Test #${t}: "

	res=$(python3 check_schedulability.py ${t})

	# NOTE: we are doing case insensitive matching.  If this is not what you want,
	# just remove the "-i" flag
	# Ignoring blank spaces
	if [[ "$res" == "PASS" ]]
	then
		echo -e "\e[0;32mPASS\e[0m"
		marks_1="$marks_1,1" # 1 mark for pass
		marks_2="$marks_2,1" # 1 mark for pass
		((total_test++))
	else
		echo -e "\e[0;31mFAIL\e[0m"
		marks_1="$marks_1,0" # 0 mark for fail
		marks_2="$marks_2,0" # 0 mark for fail
		echo "Output for test case $t:" >> .output
		cat res_assig2_$t >> .output
	fi
done
echo "Marks of the student(s) are"
echo -e "$marks_1\n$marks_2"
